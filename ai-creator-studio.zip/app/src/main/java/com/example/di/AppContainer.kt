package com.example.di

import android.content.Context
import com.example.data.config.AppConfig
import com.example.data.local.AppDatabase
import com.example.data.service.GeminiService
import com.example.data.service.GeminiServiceImpl
import com.example.data.service.ImageGenerationService
import com.example.data.service.ImageGenerationServiceImpl
import com.example.data.service.LiveAIService
import com.example.data.service.LiveAIServiceImpl
import com.example.data.service.ProjectService
import com.example.data.service.ProjectServiceImpl
import com.example.data.service.VideoGenerationService
import com.example.data.service.VideoGenerationServiceImpl
import com.example.data.service.VoiceGenerationService
import com.example.data.service.VoiceGenerationServiceImpl

object AppContainer {
    private var initialized = false

    lateinit var database: AppDatabase
        private set

    lateinit var geminiService: GeminiService
        private set

    lateinit var imageGenerationService: ImageGenerationService
        private set

    lateinit var videoGenerationService: VideoGenerationService
        private set

    lateinit var liveAIService: LiveAIService
        private set

    lateinit var voiceGenerationService: VoiceGenerationService
        private set

    lateinit var projectService: ProjectService
        private set

    fun initialize(context: Context) {
        if (!initialized) {
            val appContext = context.applicationContext
            AppConfig.init(appContext)

            database = AppDatabase.getDatabase(appContext)
            geminiService = GeminiServiceImpl()
            imageGenerationService = ImageGenerationServiceImpl()
            videoGenerationService = VideoGenerationServiceImpl()

            liveAIService = LiveAIServiceImpl(geminiService).apply {
                init(appContext)
            }

            voiceGenerationService = VoiceGenerationServiceImpl().apply {
                init(appContext)
            }

            projectService = ProjectServiceImpl(database)

            initialized = true
        }
    }
}
