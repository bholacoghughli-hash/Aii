package com.example.data.model

enum class ProjectType(val displayName: String) {
    IMAGE("AI Image"),
    VIDEO("AI Video"),
    CHAT("AI Chat"),
    AUDIO("AI Voice")
}

enum class ImageStyle(val displayName: String, val promptModifier: String) {
    REALISTIC("Realistic", "photorealistic, hyper-detailed, 8k resolution, realistic lighting, highly detailed textures"),
    CINEMATIC("Cinematic", "cinematic lighting, dramatic atmosphere, 35mm film still, depth of field, blockbuster movie aesthetic"),
    ANIME("Anime", "Japanese anime style, vibrant colors, clean lineart, Makoto Shinkai aesthetic, dynamic lighting"),
    THREE_D("3D", "3D render, Unreal Engine 5, Octane render, volumetric lighting, smooth 3D geometry, raytraced"),
    CARTOON("Cartoon", "playful cartoon illustration, expressive characters, bold outlines, vibrant flat colors"),
    FANTASY("Fantasy", "epic fantasy art, mythical glowing elements, ethereal atmosphere, concept art, magical realism")
}

enum class ImageAspectRatio(val displayName: String, val apiValue: String, val widthRatio: Float, val heightRatio: Float) {
    SQUARE("1:1", "1:1", 1f, 1f),
    LANDSCAPE("16:9", "16:9", 16f, 9f),
    PORTRAIT("9:16", "9:16", 9f, 16f),
    PHOTO_LANDSCAPE("4:3", "4:3", 4f, 3f),
    PHOTO_PORTRAIT("3:4", "3:4", 3f, 4f)
}

enum class VideoMode(val displayName: String) {
    TEXT_TO_VIDEO("Text to Video"),
    IMAGE_TO_VIDEO("Image to Video")
}

enum class VideoStatus(val displayName: String) {
    QUEUED("Queued"),
    PROCESSING("Processing"),
    GENERATING("Generating"),
    COMPLETED("Completed"),
    FAILED("Failed")
}

enum class LiveStatus(val displayName: String) {
    DISCONNECTED("Disconnected"),
    CONNECTING("Connecting..."),
    CONNECTED("Connected")
}

enum class VoiceLanguage(val displayName: String, val code: String) {
    ENGLISH("English", "en"),
    HINDI("Hindi", "hi")
}

data class VoiceOption(
    val id: String,
    val name: String,
    val description: String,
    val gender: String,
    val region: String = "US"
)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class CreatorPromptTemplate(
    val title: String,
    val category: String,
    val prompt: String,
    val iconName: String
)

data class GenerationHistoryItem(
    val id: Long,
    val title: String,
    val type: ProjectType,
    val timeAgo: String,
    val details: String
)
