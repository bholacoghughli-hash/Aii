package com.example.data.service

import com.example.data.local.AppDatabase
import com.example.data.local.FeedbackEntity
import com.example.data.local.ProjectEntity
import kotlinx.coroutines.flow.Flow

interface ProjectService {
    fun getAllProjects(): Flow<List<ProjectEntity>>
    fun getProjectsByType(type: String): Flow<List<ProjectEntity>>
    fun getRecentProjects(limit: Int = 5): Flow<List<ProjectEntity>>
    suspend fun getProjectById(id: Long): ProjectEntity?
    suspend fun saveProject(project: ProjectEntity): Long
    suspend fun updateProject(project: ProjectEntity)
    suspend fun renameProject(id: Long, newTitle: String)
    suspend fun deleteProject(project: ProjectEntity)
    suspend fun deleteProjectById(id: Long)
    fun getProjectCount(): Flow<Int>

    fun getAllFeedback(): Flow<List<FeedbackEntity>>
    suspend fun submitFeedback(feedback: FeedbackEntity): Long
}

class ProjectServiceImpl(
    private val database: AppDatabase
) : ProjectService {
    override fun getAllProjects(): Flow<List<ProjectEntity>> = database.projectDao().getAllProjects()

    override fun getProjectsByType(type: String): Flow<List<ProjectEntity>> =
        database.projectDao().getProjectsByType(type)

    override fun getRecentProjects(limit: Int): Flow<List<ProjectEntity>> =
        database.projectDao().getRecentProjects(limit)

    override fun getProjectCount(): Flow<Int> = database.projectDao().getProjectCount()

    override suspend fun getProjectById(id: Long): ProjectEntity? = database.projectDao().getProjectById(id)

    override suspend fun saveProject(project: ProjectEntity): Long = database.projectDao().insertProject(project)

    override suspend fun updateProject(project: ProjectEntity) = database.projectDao().updateProject(project)

    override suspend fun renameProject(id: Long, newTitle: String) = database.projectDao().renameProject(id, newTitle)

    override suspend fun deleteProject(project: ProjectEntity) = database.projectDao().deleteProject(project)

    override suspend fun deleteProjectById(id: Long) = database.projectDao().deleteProjectById(id)

    override fun getAllFeedback(): Flow<List<FeedbackEntity>> = database.feedbackDao().getAllFeedback()

    override suspend fun submitFeedback(feedback: FeedbackEntity): Long =
        database.feedbackDao().insertFeedback(feedback)
}
