package com.example.data.service

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.data.config.AppConfig
import com.example.data.model.ImageAspectRatio
import com.example.data.model.ImageStyle
import com.example.data.remote.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class ImageGenerationResult(
    val base64Image: String,
    val mimeType: String,
    val prompt: String,
    val style: String,
    val aspectRatio: String,
    val bitmap: Bitmap?
)

interface ImageGenerationService {
    suspend fun generateImage(
        prompt: String,
        style: ImageStyle,
        aspectRatio: ImageAspectRatio
    ): Result<ImageGenerationResult>
}

class ImageGenerationServiceImpl : ImageGenerationService {
    private val client = NetworkClient.okHttpClient
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    override suspend fun generateImage(
        prompt: String,
        style: ImageStyle,
        aspectRatio: ImageAspectRatio
    ): Result<ImageGenerationResult> = withContext(Dispatchers.IO) {
        val apiKey = AppConfig.getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Image generation provider is not configured. Please set your Gemini API key in Settings/Profile.")
            )
        }

        try {
            val enhancedPrompt = "${prompt.trim()}, ${style.promptModifier}"

            val rootJson = JSONObject()

            // Contents
            val contentsArray = JSONArray()
            val turnObj = JSONObject()
            val partsArr = JSONArray().put(JSONObject().put("text", enhancedPrompt))
            turnObj.put("parts", partsArr)
            contentsArray.put(turnObj)
            rootJson.put("contents", contentsArray)

            // Generation config with image modalities
            val genConfig = JSONObject()
            val modalities = JSONArray().put("TEXT").put("IMAGE")
            genConfig.put("responseModalities", modalities)

            val imageConfig = JSONObject()
            imageConfig.put("aspectRatio", aspectRatio.apiValue)
            imageConfig.put("imageSize", "1K")
            genConfig.put("imageConfig", imageConfig)

            rootJson.put("generationConfig", genConfig)

            // Use gemini-2.5-flash-image
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=$apiKey"
            val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMsg = try {
                    val errJson = JSONObject(responseBody)
                    errJson.getJSONObject("error").getString("message")
                } catch (e: Exception) {
                    "HTTP ${response.code}: ${response.message}"
                }
                return@withContext Result.failure(Exception("Image Generation API Error: $errorMsg"))
            }

            val resJson = JSONObject(responseBody)
            val candidates = resJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(Exception("No image candidate returned by the image generation model."))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            var foundBase64: String? = null
            var mimeType = "image/png"

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        foundBase64 = inlineData.optString("data")
                        mimeType = inlineData.optString("mimeType", "image/png")
                        if (!foundBase64.isNullOrBlank()) break
                    }
                }
            }

            if (foundBase64.isNullOrBlank()) {
                // If model returned text explanation instead of image
                val textPart = parts?.optJSONObject(0)?.optString("text")
                val explanation = if (!textPart.isNullOrBlank()) " ($textPart)" else ""
                return@withContext Result.failure(
                    Exception("Image generation provider did not return image data$explanation. Ensure model 'gemini-2.5-flash-image' is enabled.")
                )
            }

            val decodedBytes = Base64.decode(foundBase64, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)

            Result.success(
                ImageGenerationResult(
                    base64Image = foundBase64,
                    mimeType = mimeType,
                    prompt = prompt,
                    style = style.displayName,
                    aspectRatio = aspectRatio.displayName,
                    bitmap = bitmap
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
