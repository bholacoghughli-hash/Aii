package com.example.data.service

import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.model.VoiceLanguage
import com.example.data.model.VoiceOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

data class GeneratedVoiceData(
    val audioFilePath: String,
    val text: String,
    val language: VoiceLanguage,
    val voice: VoiceOption,
    val durationMs: Long
)

interface VoiceGenerationService {
    val isPlaying: StateFlow<Boolean>
    val playbackProgress: StateFlow<Float>

    fun init(context: Context)
    suspend fun generateVoice(
        text: String,
        language: VoiceLanguage,
        voice: VoiceOption,
        speed: Float = 1.0f,
        pitch: Float = 1.0f
    ): Result<GeneratedVoiceData>

    fun playAudio(filePath: String, onCompletion: () -> Unit = {})
    fun pauseAudio()
    fun stopAudio()
    fun shutdown()
}

class VoiceGenerationServiceImpl : VoiceGenerationService {
    private var context: Context? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var mediaPlayer: MediaPlayer? = null

    private val _isPlaying = MutableStateFlow(false)
    override val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f)
    override val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    override fun init(context: Context) {
        this.context = context.applicationContext
        if (tts == null) {
            tts = TextToSpeech(this.context) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isTtsReady = true
                }
            }
        }
    }

    override suspend fun generateVoice(
        text: String,
        language: VoiceLanguage,
        voice: VoiceOption,
        speed: Float,
        pitch: Float
    ): Result<GeneratedVoiceData> = withContext(Dispatchers.IO) {
        val appContext = context ?: return@withContext Result.failure(Exception("Voice service not initialized."))
        if (!isTtsReady || tts == null) {
            return@withContext Result.failure(Exception("Voice TTS engine is initializing. Please try again."))
        }

        try {
            val targetLocale = when (language) {
                VoiceLanguage.HINDI -> Locale("hi", "IN")
                VoiceLanguage.ENGLISH -> Locale.US
            }

            val langResult = tts?.setLanguage(targetLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to default locale if Hindi language pack is not installed on test device
                tts?.setLanguage(Locale.US)
            }

            tts?.setPitch(pitch)
            tts?.setSpeechRate(speed)

            val audioFile = File(appContext.cacheDir, "voice_${System.currentTimeMillis()}.wav")
            val utteranceId = "tts_gen_${System.currentTimeMillis()}"

            val params = Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)

            val synthSuccess = suspendCancellableCoroutine<Boolean> { cont ->
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(uttId: String?) {}
                    override fun onDone(uttId: String?) {
                        if (uttId == utteranceId && cont.isActive) {
                            cont.resume(true)
                        }
                    }
                    override fun onError(uttId: String?) {
                        if (uttId == utteranceId && cont.isActive) {
                            cont.resume(false)
                        }
                    }
                })

                val ret = tts?.synthesizeToFile(text, params, audioFile, utteranceId)
                if (ret != TextToSpeech.SUCCESS && cont.isActive) {
                    cont.resume(false)
                }
            }

            if (synthSuccess && audioFile.exists() && audioFile.length() > 0) {
                val durationEst = ((text.split(" ").size * 250L) / speed.coerceAtLeast(0.5f)).toLong()
                Result.success(
                    GeneratedVoiceData(
                        audioFilePath = audioFile.absolutePath,
                        text = text,
                        language = language,
                        voice = voice,
                        durationMs = durationEst
                    )
                )
            } else {
                Result.failure(Exception("Failed to synthesize speech audio file."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun playAudio(filePath: String, onCompletion: () -> Unit) {
        try {
            stopAudio()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                start()
                _isPlaying.value = true
                setOnCompletionListener {
                    _isPlaying.value = false
                    _playbackProgress.value = 1f
                    onCompletion()
                }
            }
        } catch (e: Exception) {
            _isPlaying.value = false
        }
    }

    override fun pauseAudio() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _isPlaying.value = false
            }
        }
    }

    override fun stopAudio() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }
        mediaPlayer = null
        _isPlaying.value = false
        _playbackProgress.value = 0f
    }

    override fun shutdown() {
        stopAudio()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
