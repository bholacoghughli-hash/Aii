package com.example.data.config

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class FeatureFlags(
    val imageGenerationEnabled: Boolean = true,
    val videoGenerationEnabled: Boolean = true,
    val liveAIEnabled: Boolean = true,
    val voiceEnabled: Boolean = true,
    val chatEnabled: Boolean = true,
    val projectsEnabled: Boolean = true
)

object FeatureFlagManager {
    private val _flags = MutableStateFlow(FeatureFlags())
    val flags: StateFlow<FeatureFlags> = _flags.asStateFlow()

    fun updateFlags(newFlags: FeatureFlags) {
        _flags.value = newFlags
    }

    fun isFeatureAvailable(feature: String): Boolean {
        val current = _flags.value
        return when (feature.lowercase()) {
            "image" -> current.imageGenerationEnabled
            "video" -> current.videoGenerationEnabled
            "live" -> current.liveAIEnabled
            "voice" -> current.voiceEnabled
            "chat" -> current.chatEnabled
            "projects" -> current.projectsEnabled
            else -> true
        }
    }
}
