package com.example.data.service

import com.example.data.config.AppConfig
import com.example.data.model.VideoMode
import com.example.data.model.VideoStatus
import com.example.data.remote.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID

data class VideoJobInfo(
    val jobId: String,
    val mode: VideoMode,
    val prompt: String,
    val status: VideoStatus,
    val progressPercent: Int,
    val statusMessage: String,
    val resultVideoUrl: String? = null,
    val imageBase64: String? = null,
    val aspectRatio: String,
    val durationSec: Int
)

interface VideoGenerationService {
    suspend fun createTextToVideoJob(
        prompt: String,
        aspectRatio: String,
        durationSec: Int,
        style: String
    ): Result<VideoJobInfo>

    suspend fun createImageToVideoJob(
        imageBase64: String,
        prompt: String,
        aspectRatio: String,
        durationSec: Int
    ): Result<VideoJobInfo>

    suspend fun pollJobStatus(jobId: String): Result<VideoJobInfo>
}

class VideoGenerationServiceImpl : VideoGenerationService {
    private val client = NetworkClient.okHttpClient
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    // In-memory store for tracking active beta jobs
    private val activeJobs = mutableMapOf<String, VideoJobInfo>()

    override suspend fun createTextToVideoJob(
        prompt: String,
        aspectRatio: String,
        durationSec: Int,
        style: String
    ): Result<VideoJobInfo> = withContext(Dispatchers.IO) {
        val apiKey = AppConfig.getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Video generation provider is not configured. Please add your API key in Settings.")
            )
        }

        try {
            // Attempt Veo 3.1 fast generate endpoint
            val rootJson = JSONObject()
            rootJson.put("prompt", "$prompt, $style style cinematic high definition video")
            val config = JSONObject()
            config.put("numberOfVideos", 1)
            config.put("resolution", "1080p")
            config.put("aspectRatio", aspectRatio)
            rootJson.put("config", config)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-fast-generate-preview:generateVideos?key=$apiKey"
            val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(requestBody).build()

            val response = try {
                client.newCall(request).execute()
            } catch (e: Exception) {
                null
            }

            val jobId = UUID.randomUUID().toString().take(8)

            if (response != null && response.isSuccessful) {
                val resBody = response.body?.string() ?: ""
                val resJson = JSONObject(resBody)
                val opName = resJson.optString("name", jobId)

                val job = VideoJobInfo(
                    jobId = opName,
                    mode = VideoMode.TEXT_TO_VIDEO,
                    prompt = prompt,
                    status = VideoStatus.QUEUED,
                    progressPercent = 10,
                    statusMessage = "Video generation job queued with provider...",
                    aspectRatio = aspectRatio,
                    durationSec = durationSec
                )
                activeJobs[opName] = job
                Result.success(job)
            } else {
                // If the specific provider quota or endpoint requires higher tier access
                val errDetails = if (response != null) {
                    val body = response.body?.string() ?: ""
                    try {
                        JSONObject(body).optJSONObject("error")?.optString("message") ?: "Provider response: HTTP ${response.code}"
                    } catch (e: Exception) {
                        "HTTP ${response.code}"
                    }
                } else {
                    "Provider connection timeout"
                }

                // If provider is not configured for video tier, return clear failure without fake data
                Result.failure(
                    Exception("Video generation provider is not configured for this tier: $errDetails. Video generation pipeline interface is ready.")
                )
            }
        } catch (e: Exception) {
            Result.failure(Exception("Video generation provider is not configured: ${e.localizedMessage}"))
        }
    }

    override suspend fun createImageToVideoJob(
        imageBase64: String,
        prompt: String,
        aspectRatio: String,
        durationSec: Int
    ): Result<VideoJobInfo> = withContext(Dispatchers.IO) {
        val apiKey = AppConfig.getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Video generation provider is not configured. Please add your API key in Settings.")
            )
        }

        try {
            val jobId = UUID.randomUUID().toString().take(8)
            val rootJson = JSONObject()
            rootJson.put("prompt", if (prompt.isNotBlank()) prompt else "Animate this image smoothly with cinematic camera motion")
            val config = JSONObject()
            config.put("numberOfVideos", 1)
            config.put("resolution", "720p")
            config.put("aspectRatio", aspectRatio)
            rootJson.put("config", config)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-fast-generate-preview:generateVideos?key=$apiKey"
            val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(requestBody).build()

            val response = try {
                client.newCall(request).execute()
            } catch (e: Exception) {
                null
            }

            if (response != null && response.isSuccessful) {
                val resBody = response.body?.string() ?: ""
                val resJson = JSONObject(resBody)
                val opName = resJson.optString("name", jobId)

                val job = VideoJobInfo(
                    jobId = opName,
                    mode = VideoMode.IMAGE_TO_VIDEO,
                    prompt = prompt,
                    status = VideoStatus.QUEUED,
                    progressPercent = 15,
                    statusMessage = "Image-to-video job queued with provider...",
                    imageBase64 = imageBase64,
                    aspectRatio = aspectRatio,
                    durationSec = durationSec
                )
                activeJobs[opName] = job
                Result.success(job)
            } else {
                val errDetails = if (response != null) {
                    val body = response.body?.string() ?: ""
                    try {
                        JSONObject(body).optJSONObject("error")?.optString("message") ?: "Provider response: HTTP ${response.code}"
                    } catch (e: Exception) {
                        "HTTP ${response.code}"
                    }
                } else {
                    "Provider connection timeout"
                }

                Result.failure(
                    Exception("Video generation provider is not configured for image-to-video: $errDetails")
                )
            }
        } catch (e: Exception) {
            Result.failure(Exception("Video generation provider is not configured: ${e.localizedMessage}"))
        }
    }

    override suspend fun pollJobStatus(jobId: String): Result<VideoJobInfo> = withContext(Dispatchers.IO) {
        val currentJob = activeJobs[jobId]
        if (currentJob == null) {
            return@withContext Result.failure(Exception("Job not found."))
        }
        Result.success(currentJob)
    }
}
