package com.example.data.service

import android.content.Context
import android.speech.tts.TextToSpeech
import com.example.data.config.AppConfig
import com.example.data.model.ChatMessage
import com.example.data.model.LiveStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

interface LiveAIService {
    val status: StateFlow<LiveStatus>
    val transcript: StateFlow<List<ChatMessage>>
    val isMicActive: StateFlow<Boolean>
    val isCameraActive: StateFlow<Boolean>
    val isAiSpeaking: StateFlow<Boolean>
    val audioWaveIntensity: StateFlow<Float>

    fun init(context: Context)
    fun startLiveSession(): Result<Unit>
    fun stopLiveSession()
    fun toggleMicrophone(enabled: Boolean)
    fun toggleCamera(enabled: Boolean)
    fun sendUserMessage(text: String)
    fun clearTranscript()
    fun shutdown()
}

class LiveAIServiceImpl(
    private val geminiService: GeminiService
) : LiveAIService {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _status = MutableStateFlow(LiveStatus.DISCONNECTED)
    override val status: StateFlow<LiveStatus> = _status.asStateFlow()

    private val _transcript = MutableStateFlow<List<ChatMessage>>(emptyList())
    override val transcript: StateFlow<List<ChatMessage>> = _transcript.asStateFlow()

    private val _isMicActive = MutableStateFlow(true)
    override val isMicActive: StateFlow<Boolean> = _isMicActive.asStateFlow()

    private val _isCameraActive = MutableStateFlow(false)
    override val isCameraActive: StateFlow<Boolean> = _isCameraActive.asStateFlow()

    private val _isAiSpeaking = MutableStateFlow(false)
    override val isAiSpeaking: StateFlow<Boolean> = _isAiSpeaking.asStateFlow()

    private val _audioWaveIntensity = MutableStateFlow(0.2f)
    override val audioWaveIntensity: StateFlow<Float> = _audioWaveIntensity.asStateFlow()

    override fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { initStatus ->
                if (initStatus == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.US
                    tts?.setPitch(1.05f)
                    tts?.setSpeechRate(1.0f)
                    isTtsReady = true
                }
            }
        }
    }

    override fun startLiveSession(): Result<Unit> {
        val isConfigured = AppConfig.isApiKeyConfigured()
        if (!isConfigured) {
            _status.value = LiveStatus.DISCONNECTED
            return Result.failure(
                IllegalStateException("Live AI requires Gemini API key. Please configure in Profile/Settings.")
            )
        }

        _status.value = LiveStatus.CONNECTING
        scope.launch {
            kotlinx.coroutines.delay(600)
            _status.value = LiveStatus.CONNECTED
            _audioWaveIntensity.value = 0.6f

            // Add system greeting
            val greeting = ChatMessage(
                isUser = false,
                text = "Live AI session connected. I am ready to collaborate on your creative project in real time. Speak or type your request!"
            )
            _transcript.value = listOf(greeting)
            speak(greeting.text)
        }
        return Result.success(Unit)
    }

    override fun stopLiveSession() {
        _status.value = LiveStatus.DISCONNECTED
        _isAiSpeaking.value = false
        _audioWaveIntensity.value = 0.1f
        tts?.stop()
    }

    override fun toggleMicrophone(enabled: Boolean) {
        _isMicActive.value = enabled
    }

    override fun toggleCamera(enabled: Boolean) {
        _isCameraActive.value = enabled
    }

    override fun sendUserMessage(text: String) {
        if (_status.value != LiveStatus.CONNECTED) return
        if (text.isBlank()) return

        val userMsg = ChatMessage(isUser = true, text = text.trim())
        _transcript.value = _transcript.value + userMsg

        scope.launch {
            _audioWaveIntensity.value = 0.9f
            _isAiSpeaking.value = false

            val history = _transcript.value.map { Pair(it.text, it.isUser) }
            val result = geminiService.generateChatResponse(
                messages = history,
                systemInstruction = "You are Live AI in AI Creator Studio. Keep answers snappy, conversational, concise, and focused on creative brainstorming, script feedback, and multimedia direction. Speak directly and engagingly."
            )

            result.onSuccess { responseText ->
                val aiMsg = ChatMessage(isUser = false, text = responseText)
                _transcript.value = _transcript.value + aiMsg
                speak(responseText)
            }.onFailure { error ->
                val errText = "Live AI error: ${error.localizedMessage}"
                _transcript.value = _transcript.value + ChatMessage(isUser = false, text = errText)
                _audioWaveIntensity.value = 0.3f
            }
        }
    }

    private fun speak(text: String) {
        if (isTtsReady && tts != null) {
            _isAiSpeaking.value = true
            _audioWaveIntensity.value = 0.85f
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "live_speech_${System.currentTimeMillis()}")
            scope.launch {
                // Approximate speaking duration
                val words = text.split(" ").size
                val delayMs = (words * 260L).coerceIn(1200L, 10000L)
                kotlinx.coroutines.delay(delayMs)
                _isAiSpeaking.value = false
                _audioWaveIntensity.value = 0.4f
            }
        }
    }

    override fun clearTranscript() {
        _transcript.value = emptyList()
        tts?.stop()
        _isAiSpeaking.value = false
    }

    override fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
