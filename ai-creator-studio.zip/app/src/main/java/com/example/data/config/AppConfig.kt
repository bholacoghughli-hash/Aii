package com.example.data.config

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

object AppConfig {
    const val APP_NAME = "AI Creator Studio"
    const val APP_VERSION = "Beta v0.1"
    const val AUTHOR = "Bhaskar"
    const val MISSION_STATEMENT = "Create images, videos, voice, chat and interact with AI from one Android app."

    private const val PREFS_NAME = "ai_studio_prefs"
    private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
    private const val KEY_USER_NAME = "user_name"
    private const val KEY_USER_EMAIL = "user_email"

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun getApiKey(): String {
        val customKey = prefs?.getString(KEY_CUSTOM_API_KEY, null)
        if (!customKey.isNullOrBlank()) {
            return customKey
        }
        val buildConfigKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }
        return if (buildConfigKey != "MY_GEMINI_API_KEY" && buildConfigKey.isNotBlank()) {
            buildConfigKey
        } else {
            ""
        }
    }

    fun setCustomApiKey(key: String) {
        prefs?.edit()?.putString(KEY_CUSTOM_API_KEY, key.trim())?.apply()
    }

    fun clearCustomApiKey() {
        prefs?.edit()?.remove(KEY_CUSTOM_API_KEY)?.apply()
    }

    fun isApiKeyConfigured(): Boolean {
        val key = getApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    fun getUserName(): String {
        return prefs?.getString(KEY_USER_NAME, "Beta Creator") ?: "Beta Creator"
    }

    fun setUserName(name: String) {
        prefs?.edit()?.putString(KEY_USER_NAME, name.trim())?.apply()
    }

    fun getUserEmail(): String {
        return prefs?.getString(KEY_USER_EMAIL, "creator@beta.aistudio.local") ?: "creator@beta.aistudio.local"
    }

    fun setUserEmail(email: String) {
        prefs?.edit()?.putString(KEY_USER_EMAIL, email.trim())?.apply()
    }
}
