package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val type: String, // IMAGE, VIDEO, CHAT, AUDIO
    val prompt: String,
    val resultText: String? = null,
    val resultImageBase64: String? = null,
    val resultAudioUri: String? = null,
    val resultVideoUrl: String? = null,
    val style: String? = null,
    val aspectRatio: String? = null,
    val metadata: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "beta_feedback")
data class FeedbackEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val feedbackType: String, // Problem, Suggestion, Feature Request
    val message: String,
    val userEmail: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_history")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionId: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
