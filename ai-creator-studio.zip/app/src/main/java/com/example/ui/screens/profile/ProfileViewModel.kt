package com.example.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.AppConfig
import com.example.data.config.FeatureFlags
import com.example.data.local.FeedbackEntity
import com.example.data.service.ProjectService
import com.example.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProfileUiState(
    val apiKey: String = "",
    val isKeyConfigured: Boolean = false,
    val apiKeyMasked: String = "",
    val feedbackMessage: String = "",
    val feedbackCategory: String = "SUGGESTION",
    val isFeedbackSent: Boolean = false,
    val statusNotice: String? = null
)

class ProfileViewModel(
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        loadConfig()
    }

    fun loadConfig() {
        val configured = AppConfig.isApiKeyConfigured()
        val key = AppConfig.getApiKey()
        val masked = if (key.length > 8) {
            "${key.take(4)}...${key.takeLast(4)}"
        } else if (key.isNotBlank()) {
            "••••••••"
        } else {
            "Not Set"
        }

        _uiState.value = _uiState.value.copy(
            apiKey = key,
            isKeyConfigured = configured,
            apiKeyMasked = masked
        )
    }

    fun saveCustomApiKey(key: String) {
        AppConfig.setCustomApiKey(key.trim())
        loadConfig()
        _uiState.value = _uiState.value.copy(statusNotice = "API Key saved successfully.")
    }

    fun clearApiKey() {
        AppConfig.clearCustomApiKey()
        loadConfig()
        _uiState.value = _uiState.value.copy(statusNotice = "Custom API Key cleared.")
    }

    fun updateFeedbackMessage(msg: String) {
        _uiState.value = _uiState.value.copy(feedbackMessage = msg)
    }

    fun selectFeedbackCategory(cat: String) {
        _uiState.value = _uiState.value.copy(feedbackCategory = cat)
    }

    fun submitFeedback(onComplete: () -> Unit = {}) {
        val msg = _uiState.value.feedbackMessage.trim()
        if (msg.isBlank()) return

        viewModelScope.launch {
            val entity = FeedbackEntity(
                feedbackType = _uiState.value.feedbackCategory,
                message = msg,
                userEmail = AppConfig.getUserEmail()
            )
            projectService.submitFeedback(entity)
            _uiState.value = _uiState.value.copy(
                isFeedbackSent = true,
                feedbackMessage = "",
                statusNotice = "Thank you for beta feedback!"
            )
            onComplete()
        }
    }

    fun clearNotice() {
        _uiState.value = _uiState.value.copy(statusNotice = null)
    }
}
