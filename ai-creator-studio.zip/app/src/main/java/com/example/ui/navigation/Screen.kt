package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    object Create : Screen("create", "Create", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
    object Projects : Screen("projects", "Projects", Icons.Filled.Folder, Icons.Outlined.Folder)
    object Live : Screen("live", "Live AI", Icons.Filled.GraphicEq, Icons.Outlined.GraphicEq)
    object Profile : Screen("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)

    // Sub-screens under Create / Studio
    object ImageStudio : Screen("image_studio", "AI Image", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
    object VideoStudio : Screen("video_studio", "AI Video", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
    object ChatStudio : Screen("chat_studio", "AI Chat", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
    object VoiceStudio : Screen("voice_studio", "AI Voice", Icons.Filled.GraphicEq, Icons.Outlined.GraphicEq)
}

val BottomNavScreens = listOf(
    Screen.Home,
    Screen.Create,
    Screen.Projects,
    Screen.Live,
    Screen.Profile
)
