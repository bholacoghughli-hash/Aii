package com.example.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.AppConfig
import com.example.data.local.ProjectEntity
import com.example.data.model.CreatorPromptTemplate
import com.example.data.service.ProjectService
import com.example.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val isApiKeyConfigured: Boolean = false,
    val totalCreations: Int = 0,
    val promptTemplates: List<CreatorPromptTemplate> = emptyList()
)

class HomeViewModel(
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    val recentProjects: StateFlow<List<ProjectEntity>> = projectService.getRecentProjects(5)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val projectCount: StateFlow<Int> = projectService.getProjectCount()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        refreshState()
    }

    fun refreshState() {
        val configured = AppConfig.isApiKeyConfigured()
        val templates = listOf(
            CreatorPromptTemplate(
                title = "Viral YouTube Hook",
                category = "Scripts",
                prompt = "Write 5 high-retention opening hooks for a video about futuristic artificial intelligence gadgets.",
                iconName = "smart_display"
            ),
            CreatorPromptTemplate(
                title = "Cyberpunk Hero Shot",
                category = "Image Prompts",
                prompt = "Hyper-detailed portrait of a cybernetic visionary in neon Tokyo rain, volumetric lighting, 8k resolution.",
                iconName = "palette"
            ),
            CreatorPromptTemplate(
                title = "Cinematic Drone Loop",
                category = "Video Prompts",
                prompt = "Cinematic aerial drone shot sweeping over mist-shrouded emerald mountains at sunrise, 4k cinematic lighting.",
                iconName = "videocam"
            ),
            CreatorPromptTemplate(
                title = "Hindi Podcast Intro",
                category = "Audio Voice",
                prompt = "Namaste aur swagat hai aapka AI Creator Studio podcast mein, jahan hum future of technology explore karenge.",
                iconName = "graphic_eq"
            )
        )
        _uiState.value = HomeUiState(
            isApiKeyConfigured = configured,
            totalCreations = projectCount.value,
            promptTemplates = templates
        )
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            projectService.deleteProjectById(id)
        }
    }
}
