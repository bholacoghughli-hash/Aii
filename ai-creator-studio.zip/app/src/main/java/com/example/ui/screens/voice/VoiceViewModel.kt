package com.example.ui.screens.voice

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProjectEntity
import com.example.data.model.VoiceLanguage
import com.example.data.model.VoiceOption
import com.example.data.service.GeneratedVoiceData
import com.example.data.service.ProjectService
import com.example.data.service.VoiceGenerationService
import com.example.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class VoiceUiState(
    val text: String = "",
    val selectedLanguage: VoiceLanguage = VoiceLanguage.ENGLISH,
    val selectedVoice: VoiceOption = VoiceOption("kore", "Kore", "Calm Female", "Female", "US"),
    val speechSpeed: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val isGenerating: Boolean = false,
    val generatedData: GeneratedVoiceData? = null,
    val errorMessage: String? = null,
    val isSavedToProjects: Boolean = false
)

class VoiceViewModel(
    private val voiceService: VoiceGenerationService = AppContainer.voiceGenerationService,
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    val isPlaying: StateFlow<Boolean> = voiceService.isPlaying

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    val availableVoicesEnglish = listOf(
        VoiceOption("kore", "Kore", "Calm & Studio", "Female", "US"),
        VoiceOption("fenrir", "Fenrir", "Deep Cinematic", "Male", "US"),
        VoiceOption("aoede", "Aoede", "Warm Storytelling", "Female", "US"),
        VoiceOption("puck", "Puck", "Playful Dynamic", "Male", "US"),
        VoiceOption("charon", "Charon", "Authoritative", "Male", "US")
    )

    val availableVoicesHindi = listOf(
        VoiceOption("swara", "Swara", "Clear Hindi Female", "Female", "IN"),
        VoiceOption("aarav", "Aarav", "Warm Hindi Male", "Male", "IN")
    )

    fun updateText(text: String) {
        _uiState.value = _uiState.value.copy(text = text)
    }

    fun selectLanguage(lang: VoiceLanguage) {
        val defaultVoice = if (lang == VoiceLanguage.HINDI) availableVoicesHindi.first() else availableVoicesEnglish.first()
        _uiState.value = _uiState.value.copy(
            selectedLanguage = lang,
            selectedVoice = defaultVoice
        )
    }

    fun selectVoice(voice: VoiceOption) {
        _uiState.value = _uiState.value.copy(selectedVoice = voice)
    }

    fun updateSpeed(speed: Float) {
        _uiState.value = _uiState.value.copy(speechSpeed = speed)
    }

    fun updatePitch(pitch: Float) {
        _uiState.value = _uiState.value.copy(speechPitch = pitch)
    }

    fun generateVoice() {
        val currentText = _uiState.value.text.trim()
        if (currentText.isBlank()) return

        _uiState.value = _uiState.value.copy(
            isGenerating = true,
            errorMessage = null,
            isSavedToProjects = false
        )

        viewModelScope.launch {
            val result = voiceService.generateVoice(
                text = currentText,
                language = _uiState.value.selectedLanguage,
                voice = _uiState.value.selectedVoice,
                speed = _uiState.value.speechSpeed,
                pitch = _uiState.value.speechPitch
            )

            result.onSuccess { data ->
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    generatedData = data,
                    errorMessage = null
                )
                // Automatically play generated audio
                voiceService.playAudio(data.audioFilePath)
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    errorMessage = error.localizedMessage ?: "Voice generation failed."
                )
            }
        }
    }

    fun togglePlayPause() {
        val data = _uiState.value.generatedData ?: return
        if (isPlaying.value) {
            voiceService.pauseAudio()
        } else {
            voiceService.playAudio(data.audioFilePath)
        }
    }

    fun saveToProjects(onSaved: () -> Unit = {}) {
        val data = _uiState.value.generatedData ?: return
        viewModelScope.launch {
            val project = ProjectEntity(
                title = "Voice: ${data.text.take(30)}...",
                type = "AUDIO",
                prompt = data.text,
                resultAudioUri = data.audioFilePath,
                metadata = "Lang: ${data.language.displayName} | Voice: ${data.voice.name}"
            )
            projectService.saveProject(project)
            _uiState.value = _uiState.value.copy(isSavedToProjects = true)
            onSaved()
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    override fun onCleared() {
        super.onCleared()
        voiceService.stopAudio()
    }
}
