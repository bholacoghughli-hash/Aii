package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary AI Creator Studio Palette - Luxury Cyber Slate & Glowing Neon Accents
val StudioPrimary = Color(0xFF6366F1) // Indigo 500
val StudioPrimaryLight = Color(0xFF818CF8) // Indigo 400
val StudioPrimaryDark = Color(0xFF4338CA) // Indigo 700

val StudioSecondary = Color(0xFF06B6D4) // Cyan 500
val StudioSecondaryDark = Color(0xFF0E7490) // Cyan 700

val StudioTertiary = Color(0xFFEC4899) // Pink 500
val StudioAccentAmber = Color(0xFFF59E0B) // Amber 500
val StudioAccentGreen = Color(0xFF10B981) // Emerald 500
val StudioAccentPurple = Color(0xFFA855F7) // Purple 500

// Dark Theme Surfaces
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkSurfaceElevated = Color(0xFF283548)
val DarkBorder = Color(0xFF374151)
val DarkTextPrimary = Color(0xFFF9FAFB)
val DarkTextSecondary = Color(0xFF9CA3AF)

// Light Theme Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceElevated = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Beta Badge Colors
val BetaBadgeBg = Color(0x33F59E0B)
val BetaBadgeText = Color(0xFFFBBF24)
