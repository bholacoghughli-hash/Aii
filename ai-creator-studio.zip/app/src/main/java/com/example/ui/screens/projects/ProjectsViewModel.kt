package com.example.ui.screens.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProjectEntity
import com.example.data.service.ProjectService
import com.example.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProjectsUiState(
    val selectedFilter: String = "ALL",
    val searchQuery: String = "",
    val activeDetailProject: ProjectEntity? = null,
    val renamingProject: ProjectEntity? = null
)

class ProjectsViewModel(
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProjectsUiState())
    val uiState: StateFlow<ProjectsUiState> = _uiState.asStateFlow()

    private val rawProjects = projectService.getAllProjects()

    val filteredProjects: StateFlow<List<ProjectEntity>> = combine(
        rawProjects,
        _uiState
    ) { projects, state ->
        projects.filter { item ->
            val matchesFilter = when (state.selectedFilter) {
                "IMAGE" -> item.type == "IMAGE"
                "VIDEO" -> item.type == "VIDEO"
                "CHAT" -> item.type == "CHAT"
                "AUDIO" -> item.type == "AUDIO"
                else -> true
            }
            val matchesSearch = if (state.searchQuery.isBlank()) {
                true
            } else {
                item.title.contains(state.searchQuery, ignoreCase = true) ||
                item.prompt.contains(state.searchQuery, ignoreCase = true) ||
                (item.resultText?.contains(state.searchQuery, ignoreCase = true) ?: false)
            }
            matchesFilter && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun selectFilter(filter: String) {
        _uiState.value = _uiState.value.copy(selectedFilter = filter)
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun openProjectDetail(project: ProjectEntity) {
        _uiState.value = _uiState.value.copy(activeDetailProject = project)
    }

    fun closeProjectDetail() {
        _uiState.value = _uiState.value.copy(activeDetailProject = null)
    }

    fun startRenaming(project: ProjectEntity) {
        _uiState.value = _uiState.value.copy(renamingProject = project)
    }

    fun finishRenaming(newTitle: String) {
        val proj = _uiState.value.renamingProject ?: return
        if (newTitle.isNotBlank()) {
            viewModelScope.launch {
                projectService.renameProject(proj.id, newTitle.trim())
                _uiState.value = _uiState.value.copy(renamingProject = null)
            }
        } else {
            _uiState.value = _uiState.value.copy(renamingProject = null)
        }
    }

    fun cancelRenaming() {
        _uiState.value = _uiState.value.copy(renamingProject = null)
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            projectService.deleteProject(project)
            if (_uiState.value.activeDetailProject?.id == project.id) {
                _uiState.value = _uiState.value.copy(activeDetailProject = null)
            }
        }
    }
}
