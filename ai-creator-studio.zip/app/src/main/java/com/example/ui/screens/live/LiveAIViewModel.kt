package com.example.ui.screens.live

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.AppConfig
import com.example.data.local.ProjectEntity
import com.example.data.model.ChatMessage
import com.example.data.model.LiveStatus
import com.example.data.service.LiveAIService
import com.example.data.service.ProjectService
import com.example.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LiveUiState(
    val status: LiveStatus = LiveStatus.DISCONNECTED,
    val isMicEnabled: Boolean = true,
    val isCameraEnabled: Boolean = false,
    val isAiSpeaking: Boolean = false,
    val errorMessage: String? = null,
    val textInput: String = ""
)

class LiveAIViewModel(
    private val liveService: LiveAIService = AppContainer.liveAIService,
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    val status: StateFlow<LiveStatus> = liveService.status
    val transcript: StateFlow<List<ChatMessage>> = liveService.transcript
    val isMicActive: StateFlow<Boolean> = liveService.isMicActive
    val isCameraActive: StateFlow<Boolean> = liveService.isCameraActive
    val isAiSpeaking: StateFlow<Boolean> = liveService.isAiSpeaking
    val audioWaveIntensity: StateFlow<Float> = liveService.audioWaveIntensity

    private val _uiState = MutableStateFlow(LiveUiState())
    val uiState: StateFlow<LiveUiState> = _uiState.asStateFlow()

    fun updateInputText(text: String) {
        _uiState.value = _uiState.value.copy(textInput = text)
    }

    fun startLive() {
        if (!AppConfig.isApiKeyConfigured()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Live AI requires Gemini API key. Please configure your key in Profile/Settings."
            )
            return
        }

        _uiState.value = _uiState.value.copy(errorMessage = null)
        val result = liveService.startLiveSession()
        result.onFailure { error ->
            _uiState.value = _uiState.value.copy(
                errorMessage = error.localizedMessage ?: "Failed to connect Live AI."
            )
        }
    }

    fun stopLive() {
        liveService.stopLiveSession()
    }

    fun toggleMic() {
        val nextState = !isMicActive.value
        liveService.toggleMicrophone(nextState)
    }

    fun toggleCamera() {
        val nextState = !isCameraActive.value
        liveService.toggleCamera(nextState)
    }

    fun sendTextMessage() {
        val currentText = _uiState.value.textInput.trim()
        if (currentText.isBlank()) return
        _uiState.value = _uiState.value.copy(textInput = "")
        liveService.sendUserMessage(currentText)
    }

    fun clearTranscript() {
        liveService.clearTranscript()
    }

    fun saveLiveSessionToProjects(onSaved: () -> Unit = {}) {
        val messages = transcript.value
        if (messages.isEmpty()) return
        viewModelScope.launch {
            val transcriptText = messages.joinToString("\n\n") {
                "${if (it.isUser) "Creator" else "Live AI"}: ${it.text}"
            }
            val project = ProjectEntity(
                title = "Live AI Session (${messages.size} turns)",
                type = "CHAT",
                prompt = "Real-time Live AI Collaboration",
                resultText = transcriptText
            )
            projectService.saveProject(project)
            onSaved()
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
