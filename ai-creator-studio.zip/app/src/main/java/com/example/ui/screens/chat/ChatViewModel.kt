package com.example.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.AppConfig
import com.example.data.local.ProjectEntity
import com.example.data.model.ChatMessage
import com.example.data.service.GeminiService
import com.example.data.service.ProjectService
import com.example.di.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val selectedCreatorMode: String = "All",
    val isApiKeyConfigured: Boolean = true
)

class ChatViewModel(
    private val geminiService: GeminiService = AppContainer.geminiService,
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    val creatorModes = listOf(
        "All",
        "Video Ideas",
        "Image Prompts",
        "Video Prompts",
        "Scripts",
        "Captions",
        "Titles",
        "Scene Descriptions"
    )

    init {
        checkConfig()
        if (_uiState.value.messages.isEmpty()) {
            addWelcomeMessage()
        }
    }

    private fun checkConfig() {
        _uiState.value = _uiState.value.copy(
            isApiKeyConfigured = AppConfig.isApiKeyConfigured()
        )
    }

    private fun addWelcomeMessage() {
        val welcome = ChatMessage(
            isUser = false,
            text = "Welcome to AI Creator Studio Assistant! I can help you generate viral video ideas, write full YouTube scripts, engineer image prompts, write titles, and describe cinematic scenes. Choose a creator mode above or type your prompt below."
        )
        _uiState.value = _uiState.value.copy(messages = listOf(welcome))
    }

    fun selectMode(mode: String) {
        _uiState.value = _uiState.value.copy(selectedCreatorMode = mode)
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        checkConfig()
        if (!_uiState.value.isApiKeyConfigured) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Gemini API key is not configured. Please set your API key in the Profile/Settings screen."
            )
            return
        }

        val userMessage = ChatMessage(isUser = true, text = userText.trim())
        val updatedList = _uiState.value.messages + userMessage
        _uiState.value = _uiState.value.copy(
            messages = updatedList,
            isLoading = true,
            errorMessage = null
        )

        viewModelScope.launch {
            val history = updatedList.map { Pair(it.text, it.isUser) }
            val mode = _uiState.value.selectedCreatorMode

            val result = if (mode == "All") {
                geminiService.generateChatResponse(history)
            } else {
                geminiService.generateCreatorAssistantResponse(mode, userText)
            }

            result.onSuccess { responseText ->
                val assistantMessage = ChatMessage(isUser = false, text = responseText)
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + assistantMessage,
                    isLoading = false
                )
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = error.localizedMessage ?: "Failed to generate AI response. Please try again."
                )
            }
        }
    }

    fun clearChat() {
        _uiState.value = _uiState.value.copy(messages = emptyList(), errorMessage = null)
        addWelcomeMessage()
    }

    fun saveToProjects(message: ChatMessage, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val titleSnippet = message.text.take(40).replace("\n", " ") + "..."
            val project = ProjectEntity(
                title = "Chat: $titleSnippet",
                type = "CHAT",
                prompt = "Creator Assistant (${_uiState.value.selectedCreatorMode})",
                resultText = message.text
            )
            val id = projectService.saveProject(project)
            onSaved(id)
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
