package com.example.ui.screens.image

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.AppConfig
import com.example.data.local.ProjectEntity
import com.example.data.model.ImageAspectRatio
import com.example.data.model.ImageStyle
import com.example.data.service.ImageGenerationResult
import com.example.data.service.ImageGenerationService
import com.example.data.service.ProjectService
import com.example.di.AppContainer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class ImageUiState(
    val prompt: String = "",
    val selectedStyle: ImageStyle = ImageStyle.REALISTIC,
    val selectedAspectRatio: ImageAspectRatio = ImageAspectRatio.SQUARE,
    val isGenerating: Boolean = false,
    val generationResult: ImageGenerationResult? = null,
    val errorMessage: String? = null,
    val isSavedToProjects: Boolean = false,
    val downloadedUri: String? = null
)

class ImageViewModel(
    private val imageGenerationService: ImageGenerationService = AppContainer.imageGenerationService,
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    private val _uiState = MutableStateFlow(ImageUiState())
    val uiState: StateFlow<ImageUiState> = _uiState.asStateFlow()

    fun updatePrompt(newPrompt: String) {
        _uiState.value = _uiState.value.copy(prompt = newPrompt)
    }

    fun selectStyle(style: ImageStyle) {
        _uiState.value = _uiState.value.copy(selectedStyle = style)
    }

    fun selectAspectRatio(aspectRatio: ImageAspectRatio) {
        _uiState.value = _uiState.value.copy(selectedAspectRatio = aspectRatio)
    }

    fun generateImage() {
        val currentPrompt = _uiState.value.prompt.trim()
        if (currentPrompt.isBlank()) return

        if (!AppConfig.isApiKeyConfigured()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Image generation provider is not configured. Please enter your Gemini API key in Settings/Profile.",
                generationResult = null
            )
            return
        }

        _uiState.value = _uiState.value.copy(
            isGenerating = true,
            errorMessage = null,
            isSavedToProjects = false,
            downloadedUri = null
        )

        viewModelScope.launch {
            val style = _uiState.value.selectedStyle
            val aspectRatio = _uiState.value.selectedAspectRatio

            val result = imageGenerationService.generateImage(
                prompt = currentPrompt,
                style = style,
                aspectRatio = aspectRatio
            )

            result.onSuccess { genResult ->
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    generationResult = genResult,
                    errorMessage = null
                )
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    generationResult = null,
                    errorMessage = error.localizedMessage ?: "Image generation provider failed. Ensure API key is configured with image generation model access."
                )
            }
        }
    }

    fun saveToProjects(onSaved: () -> Unit = {}) {
        val result = _uiState.value.generationResult ?: return
        viewModelScope.launch {
            val project = ProjectEntity(
                title = "Image: ${result.prompt.take(30)}...",
                type = "IMAGE",
                prompt = result.prompt,
                resultImageBase64 = result.base64Image,
                style = result.style,
                aspectRatio = result.aspectRatio
            )
            projectService.saveProject(project)
            _uiState.value = _uiState.value.copy(isSavedToProjects = true)
            onSaved()
        }
    }

    fun downloadImage(context: Context, onComplete: (Uri?) -> Unit) {
        val bitmap = _uiState.value.generationResult?.bitmap ?: return
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) {
                try {
                    val imagesDir = File(context.cacheDir, "generated_images")
                    if (!imagesDir.exists()) imagesDir.mkdirs()
                    val imageFile = File(imagesDir, "ai_image_${System.currentTimeMillis()}.png")
                    val out = FileOutputStream(imageFile)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.flush()
                    out.close()
                    Uri.fromFile(imageFile)
                } catch (e: Exception) {
                    null
                }
            }
            _uiState.value = _uiState.value.copy(downloadedUri = uri?.toString())
            onComplete(uri)
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
