package com.example.ui.screens.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.AppConfig
import com.example.data.local.ProjectEntity
import com.example.data.model.VideoMode
import com.example.data.model.VideoStatus
import com.example.data.service.ProjectService
import com.example.data.service.VideoGenerationService
import com.example.data.service.VideoJobInfo
import com.example.di.AppContainer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

data class VideoUiState(
    val mode: VideoMode = VideoMode.TEXT_TO_VIDEO,
    val prompt: String = "",
    val aspectRatio: String = "16:9",
    val durationSec: Int = 5,
    val style: String = "Cinematic",
    val selectedImageUri: Uri? = null,
    val selectedImageBitmap: Bitmap? = null,
    val selectedImageBase64: String? = null,
    val isGenerating: Boolean = false,
    val activeJob: VideoJobInfo? = null,
    val currentStatus: VideoStatus? = null,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
    val isSavedToProjects: Boolean = false
)

class VideoViewModel(
    private val videoService: VideoGenerationService = AppContainer.videoGenerationService,
    private val projectService: ProjectService = AppContainer.projectService
) : ViewModel() {

    private val _uiState = MutableStateFlow(VideoUiState())
    val uiState: StateFlow<VideoUiState> = _uiState.asStateFlow()

    fun selectMode(mode: VideoMode) {
        _uiState.value = _uiState.value.copy(mode = mode, errorMessage = null)
    }

    fun updatePrompt(prompt: String) {
        _uiState.value = _uiState.value.copy(prompt = prompt)
    }

    fun selectAspectRatio(ratio: String) {
        _uiState.value = _uiState.value.copy(aspectRatio = ratio)
    }

    fun selectDuration(seconds: Int) {
        _uiState.value = _uiState.value.copy(durationSec = seconds)
    }

    fun selectStyle(style: String) {
        _uiState.value = _uiState.value.copy(style = style)
    }

    fun onImageSelected(context: Context, uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    BitmapFactory.decodeStream(stream)
                } catch (e: Exception) {
                    null
                }
            }

            val base64 = withContext(Dispatchers.IO) {
                if (bitmap != null) {
                    val out = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
                    Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                } else null
            }

            _uiState.value = _uiState.value.copy(
                selectedImageUri = uri,
                selectedImageBitmap = bitmap,
                selectedImageBase64 = base64
            )
        }
    }

    fun generateVideo() {
        val currentPrompt = _uiState.value.prompt.trim()
        val currentMode = _uiState.value.mode

        if (currentMode == VideoMode.TEXT_TO_VIDEO && currentPrompt.isBlank()) return
        if (currentMode == VideoMode.IMAGE_TO_VIDEO && _uiState.value.selectedImageBase64 == null) return

        if (!AppConfig.isApiKeyConfigured()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Video generation provider is not configured. Please set your Gemini API key in Settings/Profile.",
                currentStatus = VideoStatus.FAILED,
                statusMessage = "Configuration required"
            )
            return
        }

        _uiState.value = _uiState.value.copy(
            isGenerating = true,
            currentStatus = VideoStatus.QUEUED,
            statusMessage = "Queued for video generation...",
            errorMessage = null,
            isSavedToProjects = false
        )

        viewModelScope.launch {
            val result = if (currentMode == VideoMode.TEXT_TO_VIDEO) {
                videoService.createTextToVideoJob(
                    prompt = currentPrompt,
                    aspectRatio = _uiState.value.aspectRatio,
                    durationSec = _uiState.value.durationSec,
                    style = _uiState.value.style
                )
            } else {
                videoService.createImageToVideoJob(
                    imageBase64 = _uiState.value.selectedImageBase64 ?: "",
                    prompt = currentPrompt,
                    aspectRatio = _uiState.value.aspectRatio,
                    durationSec = _uiState.value.durationSec
                )
            }

            result.onSuccess { job ->
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    activeJob = job,
                    currentStatus = job.status,
                    statusMessage = job.statusMessage,
                    errorMessage = null
                )
            }.onFailure { error ->
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    currentStatus = VideoStatus.FAILED,
                    statusMessage = "Generation Failed",
                    errorMessage = error.localizedMessage ?: "Video generation provider is not configured."
                )
            }
        }
    }

    fun saveToProjects(onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            val project = ProjectEntity(
                title = "Video: ${_uiState.value.prompt.take(30)}...",
                type = "VIDEO",
                prompt = _uiState.value.prompt,
                aspectRatio = _uiState.value.aspectRatio,
                style = _uiState.value.style,
                metadata = "Duration: ${_uiState.value.durationSec}s | Mode: ${_uiState.value.mode.displayName}"
            )
            projectService.saveProject(project)
            _uiState.value = _uiState.value.copy(isSavedToProjects = true)
            onSaved()
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
