package com.example.ui.screens.create

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.StudioHeader
import com.example.ui.navigation.Screen
import com.example.ui.theme.StudioAccentAmber
import com.example.ui.theme.StudioAccentGreen
import com.example.ui.theme.StudioPrimary
import com.example.ui.theme.StudioSecondary
import com.example.ui.theme.StudioTertiary

@Composable
fun CreateHubScreen(
    onNavigateToRoute: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("create_hub_screen"),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            StudioHeader(
                title = "Creator Studio",
                subtitle = "Choose an AI generative model to begin"
            )
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CreationHubCard(
                    title = "AI Image Generator",
                    description = "Generate stunning visual assets, realistic renders, anime artwork & 3D avatars with custom aspect ratios.",
                    badge = "Gemini 2.5",
                    icon = Icons.Default.Image,
                    accentColor = StudioPrimary,
                    onClick = { onNavigateToRoute(Screen.ImageStudio.route) }
                )

                CreationHubCard(
                    title = "AI Video Generator",
                    description = "Create cinematic videos from text prompts or animate your existing images with camera motion.",
                    badge = "Beta Pipeline",
                    icon = Icons.Default.Videocam,
                    accentColor = StudioTertiary,
                    onClick = { onNavigateToRoute(Screen.VideoStudio.route) }
                )

                CreationHubCard(
                    title = "AI Chat & Script Assistant",
                    description = "Brainstorm viral video ideas, full YouTube scripts, title suggestions, image prompts & scene descriptions.",
                    badge = "Gemini 3.5",
                    icon = Icons.Default.ChatBubble,
                    accentColor = StudioSecondary,
                    onClick = { onNavigateToRoute(Screen.ChatStudio.route) }
                )

                CreationHubCard(
                    title = "AI Voice & Speech Synthesizer",
                    description = "Convert text scripts into natural speech in English & Hindi with pitch, speed and voice character control.",
                    badge = "Audio TTS",
                    icon = Icons.Default.GraphicEq,
                    accentColor = StudioAccentGreen,
                    onClick = { onNavigateToRoute(Screen.VoiceStudio.route) }
                )

                CreationHubCard(
                    title = "Live AI Real-Time Assistant",
                    description = "Collaborate with an interactive multimodal AI using voice, camera vision and live conversational responses.",
                    badge = "Real-time",
                    icon = Icons.Default.AutoAwesome,
                    accentColor = StudioAccentAmber,
                    onClick = { onNavigateToRoute(Screen.Live.route) }
                )
            }
        }
    }
}

@Composable
fun CreationHubCard(
    title: String,
    description: String,
    badge: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag("create_card_${title.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = accentColor.copy(alpha = 0.15f),
                modifier = Modifier.size(52.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = accentColor.copy(alpha = 0.1f)
                    ) {
                        Text(
                            text = badge,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = accentColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
